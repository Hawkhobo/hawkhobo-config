#!/usr/bin/env bash

p=$(echo $PATH | tr ':' "\n" | sort | uniq | tr "\n" ':')
echo -e "\nexport PATH=${p}\n"
