if [ -t 0 ]; then echo "<= $0 done loading from $(pwd)."; fi
