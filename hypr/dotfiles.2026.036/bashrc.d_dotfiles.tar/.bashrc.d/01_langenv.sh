. "$HOME/.cargo/env"

eval "$(rbenv init - --no-rehash bash)"

