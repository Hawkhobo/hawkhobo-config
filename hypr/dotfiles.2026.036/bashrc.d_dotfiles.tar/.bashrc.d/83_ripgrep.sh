# an ignore file for ripgrep (avoid network drives and caches)
alias rg='rg --ignore-file=$HOME/.ripgrep_ignore'
