if [ -t 0 ]; then
  cat /proc/$$/environ | tr '\0' '\n' | grep -E '^DISPLAY='
fi
