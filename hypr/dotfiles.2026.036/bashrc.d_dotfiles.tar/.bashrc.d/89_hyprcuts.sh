alias reload_waybar='for p in $(pidof waybar | tr " " "\n"); do kill -TERM $p; done; nohup waybar &'
alias kitty='kitty --directoryt=. --detach=yes'
