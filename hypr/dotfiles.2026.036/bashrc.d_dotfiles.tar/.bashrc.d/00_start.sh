if [ -t 0 ]; then
	echo '  ~/.bashrc.d =>'
fi
