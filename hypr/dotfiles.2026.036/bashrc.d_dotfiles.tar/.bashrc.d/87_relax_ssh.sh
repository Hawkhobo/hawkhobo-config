export ssh_opts="-o UserKnownHostsFile=/dev/null -o StrictHostKeyChecking=no -o CheckHostIP=no -o LogLevel=ERROR -o ServerAliveInterval=45"
