# alias rm='rm -i'; 
alias cp='cp -i'; alias mv='mv -i'; alias ls='ls --color=auto'
set -o vi
export XDG_RUNTIME_DIR=/run/user/$(id -u)
