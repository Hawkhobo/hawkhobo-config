if [ -t 0 ] && [ -e /proc/driver/nvidia/version ]; then
  echo; cat /proc/driver/nvidia/version; echo
fi
