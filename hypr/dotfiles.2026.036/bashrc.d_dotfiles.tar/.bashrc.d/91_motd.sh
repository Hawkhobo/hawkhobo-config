funks="$HOME/.bashrc.d/72_funks.sh"

if [ -f $funks ] && [ -t 0 ]; then
  source "$funks" && my_motd
  echo
fi
