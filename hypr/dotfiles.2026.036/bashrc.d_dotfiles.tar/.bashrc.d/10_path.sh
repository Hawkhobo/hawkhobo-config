# if it's Not in the path, append it.  avoids duplication.
if ! [[ "$PATH" =~ "$HOME/bin" ]]; then
    PATH="$PATH:$HOME/bin"
fi

if ! [[ "$PATH" =~ "$HOME/go/bin" ]]; then
    PATH="$PATH:$HOME/go/bin"
fi


if ! [[ "$PATH" =~ "$HOME/.local/bin" ]]; then
    PATH="$PATH:$HOME/.local/bin"
fi

# CWD commands run as priority
if ! [[ "$PATH" =~ ".:$PATH" ]]; then
    PATH=".:$PATH"
fi

export PATH
