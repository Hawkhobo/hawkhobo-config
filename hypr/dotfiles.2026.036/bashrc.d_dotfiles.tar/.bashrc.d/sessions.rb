#!/usr/bin/env ruby
require 'colorize'
# Queries SystemD to display sessions and type of compositor for each seat.

sessions = `loginctl`.split("\n")[1..-3].map { |l|
  c = l.split; [c[0], c[2], c[3], c[6], c[7]] }
each_type = {}
sessions.each do |e|
  each_type[e.first] = [`loginctl show-session #{e.first} -p Type`.chomp.split('=').last, e[1..]]
end
each_type = each_type.sort_by { |e| e.first.to_i }
puts "Session, ".light_blue + "user,".light_red + "\t\ttty,\t\tseat,\t".light_blue + 
     "on".light_red + "\tType \t".light_yellow.underline + "\tis idle?\n".light_cyan.underline
each_type.each do |k,v|
  puts " #".light_red + "#{k}".light_yellow + 
       "\t(".light_cyan + v[1][0].light_red + ")".light_cyan + 
       "\t\t[".light_yellow + "#{v[-1][-2]}".light_blue + "]".light_yellow +
       "\t\t(".light_cyan + v[1][1].light_blue + ")".light_cyan + 
       "\ton\t".light_red + "#{v[0]}".light_yellow.underline +
       "  \t#{v[-1][-1]}".light_cyan
end; puts
