$HOME/.bashrc.d/sessions.rb
