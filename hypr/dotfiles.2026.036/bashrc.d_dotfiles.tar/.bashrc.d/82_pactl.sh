# hardcore hardware volume control with pulseaudio (also see playerctl addl.)
alias getvol='pactl get-sink-volume $(pactl get-default-sink)'
alias volup='pactl set-sink-volume $(pactl get-default-sink) +10%'
alias voldown='pactl set-sink-volume $(pactl get-default-sink) -10%'
