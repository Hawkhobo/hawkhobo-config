alias custom="cd $HOME/projects/favstreams && vi custom_list.txt"
alias favs='cd /home/matt/projects/scrapur && ./run.sh'
alias most="cd $HOME/projects/scrapur/criteria && vi most_favorite.txt"
alias wh="cd $HOME/projects/scrapur/criteria && vi whitelist.txt"
alias bl="cd $HOME/projects/scrapur/criteria && vi blacklist.txt"
